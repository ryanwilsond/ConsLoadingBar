import consloadingbar

def test_consloadingbar_progressbar():
    pass
